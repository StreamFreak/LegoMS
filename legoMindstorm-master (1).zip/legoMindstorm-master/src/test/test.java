package test;

import lejos.hardware.Button;
import lejos.hardware.Key;
import lejos.hardware.KeyListener;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.motor.EV3MediumRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.hardware.port.SensorPort;
import lejos.robotics.RegulatedMotor;
import lejos.hardware.sensor.EV3TouchSensor;

public class test {

	private static RegulatedMotor mB;

	public static void main(String[] args) throws InterruptedException {
		
		Button.RIGHT.addKeyListener(new KeyListener() {
			
			@Override
			public void keyReleased(Key k) {
				System.exit(0);
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(Key k) {
				// TODO Auto-generated method stub
				
			}
		});

		EV3TouchSensor touchSensor = new EV3TouchSensor(SensorPort.S1);
		touchSensor.setCurrentMode("Touch");
		float[] touchSample = new float[touchSensor.sampleSize()];

		mB = new EV3LargeRegulatedMotor(MotorPort.B);
		RegulatedMotor mA = new EV3LargeRegulatedMotor(MotorPort.A);
		mB.synchronizeWith(new RegulatedMotor[] { mA });
		@SuppressWarnings("resource")
		RegulatedMotor mC = new EV3MediumRegulatedMotor(MotorPort.C);

		mB.startSynchronization();

		while (true) {

			mB.forward();
			mA.forward();
			mB.endSynchronization();

//		Thread.sleep(10000);

			do {
				touchSensor.fetchSample(touchSample, 0);
			} while ((touchSample[0] == 0.0));
//	} while ((touchSample[0] == 0.0) && Button.ENTER.isUp());
			touchSample[0] = 0.0F;

			mC.rotate(65);
			mB.backward();
			mA.backward();
			Thread.sleep(4000);
			mB.stop();
			mA.stop();
			mC.rotate(-75);
		}

		
	}

}

//		Motor.A.backward();
//		Thread.sleep(10000);
//		Motor.A.stop();
//
//		Motor.B.backward();
//		Thread.sleep(10000);
//		Motor.B.stop();		
